package com.utn.modelo;

public class Zapatilla extends Producto {

	public Zapatilla(String marca, Object talle, double precio) {
		super(marca, talle, precio);
		// TODO Auto-generated constructor stub
	}

}
