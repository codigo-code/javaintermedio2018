package com.utn.modelo;

public enum Tipo {

	CAMISA,
	ZAPATILLA,
	PANTALON
}
