package com.utn.vista;

import com.utn.controlador.ClienteControlador;

public class Test {

	public static void main(String[] args) {

			ClienteControlador cc = new ClienteControlador();
			
			cc.alquiloPelicula();
			
			
	}

}
