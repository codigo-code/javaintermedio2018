package com.utn.modelo;

public enum Genero {

	ACCION,
	TERROR,
	PORNO
}
