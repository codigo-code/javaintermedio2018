Curso java intermeedio UTN 2018 


TIEMPO RESTANTE

PARA GUARDAR EL EXAMEN PRACTICO

0) Su examen debe contener o la carpeta con su nombre y apellido o un archivo txt
   que diga quien es la persona
1) git clone https://github.com/javautn/javaintermedio2018.git
2) cd  javaintermedio2018
3) git checkout examenheladeria
4) copiar dicho proyecto dentro de la carpeta javaintermedio2018
4biz) git fetch --all
5) git checkout examenheladeria
6) en la consola escriben:
   
   git add -A
   git commit -am "examen Cosme Fulanito"
   git pull origin examenheladeria
   git push origin examenheladeria
7) si quieren enviarlo por correo es a: panella.dante@gmail.com  
