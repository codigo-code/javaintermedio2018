package com.utn.modelo;

public class Camisa extends Producto {

	public Camisa(String marca, Object talle, double precio) {
		super(marca, talle, precio);
		// TODO Auto-generated constructor stub
	}

}
