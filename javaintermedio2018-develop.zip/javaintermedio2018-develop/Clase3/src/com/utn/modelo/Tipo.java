package com.utn.modelo;

public enum Tipo {

	ZAPATILLA,
	PANTALON,
	CAMISA
}
