package com.utn.modelo;

public class Politico implements IDialecto {

	@Override
	public void hablar(String idioma, String situacion) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void comunicarse(String situacion) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String insultar(int lvlEnojo) {
		// TODO Auto-generated method stub
		return null;
	}

}
