package com.utn.modelo;

public enum TipoPersona {

	ALUMNO,
	HINCHAFUTBOL,
	POLITICO
	
}
