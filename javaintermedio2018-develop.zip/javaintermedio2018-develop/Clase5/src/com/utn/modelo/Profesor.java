package com.utn.modelo;

public class Profesor {

}
